<?php 
  session_start();
  
  if (isset($_SESSION['ac_lvl'])  == 1) {
    # code...
    header("Location: dashboard/examples/dashboard.php");
  }
  elseif (isset($_SESSION['ac_lvl']) == 2) {
    # code...
    header("Location : user dashboard/examples/dashboard.php");
  }

?>

<!DOCTYPE html>
<html lang="en">
  
  <head>
  	<meta charset="utf-8" />
  	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    
    <title>JUMANJI ZOO</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
  	<link href="css/style.css" rel="stylesheet" />    
    
    <!--     Fonts     -->
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>   
  </head>

<body>
<nav class="navbar navbar-transparent navbar-fixed-top" role="navigation">  
  <div class="container">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li>
          <a href="#"> 
            <button type="submit" class="btn btn-secondary btn-fill">Home</button>
          </a>
        </li>
        <li>
          <a href="about.php"> 
            <button type="submit" class="btn btn-secondary btn-fill">About</button>
          </a>
        </li>
        <li>
          <a href="login.php"> 
            <button type="submit" class="btn btn-danger btn-fill">Login</button>
          </a>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>
<div class="main" style="background-image: url('images/monkey.png')">

<!--    Change the image source '/images/default.jpg' with your favourite image.     -->
    
    <div class="cover black" data-color="black"></div>
     
<!--   You can change the black color for the filter with those colors: blue, green, red, orange       -->

    <div class="container">
      <h1 class="logo cursive">ZOO JUMANJI</h1>
<!--  H1 can have 2 designs: "logo" and "logo cursive"           -->
        
      <div class="content">
        <h2 class="motto">Why conserving every animal species counts. Connect with us and share more love for animals. Save together or crash together ! </h2>
          <div class="subscribe">
            <div class="row">
              <div class="col-md-4 col-md-offset-4 col-sm6-6 col-sm-offset-3 ">

                <form class="form-inline" action="includes/newsletter.inc.php" method="POST">
                  <div class="form-group">
                    <label class="sr-only">Email address</label>
                    <input type="text" name="newsletter_email" class="form-control transparent" placeholder="Your email here...">
                  </div>
                  <button name="subscribe" class="btn btn-danger btn-fill">Subscribe</button>
                </form>

              </div>
            </div>
          </div>
      </div>
    </div>
 </div>
 </body>
   <script src="js/jquery-1.10.2.js" type="text/javascript"></script>
   <script src="js/bootstrap.min.js" type="text/javascript"></script>
</html>