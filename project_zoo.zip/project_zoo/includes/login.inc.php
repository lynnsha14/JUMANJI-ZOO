<?php 

if (isset($_POST['login'])) {
	
	require 'dbcon.inc.php';

	$email = $_POST['email'];
	$password = $_POST['pwd'];
	
	if (empty($email) || empty($password)) {
		header("Location: ../login.php?loginerror=emptyfeilds");
		exit();
	}
	else {
		$sql = "SELECT * FROM users WHERE user_name=? OR user_email=?;";
		$stmt = mysqli_stmt_init($conn);
		if (!mysqli_stmt_prepare($stmt, $sql)) {
		 	header("Location: ../login.php?loginerror=sqlerror");
			exit();
		}
		
		else {	

			mysqli_stmt_bind_param($stmt, "ss", $email, $email);
			mysqli_stmt_execute($stmt);
			$result = mysqli_stmt_get_result($stmt);
			if ($row = mysqli_fetch_assoc($result)) {
				$pwdCheck = password_verify($password, $row['user_pwd']);
				if ($pwdCheck == false) {
					header("Location: ../login.php?error=wrongpassword");
					exit();
				}
				else if ($pwdCheck == true) {
					
					if ($row['access_level'] == "1") {
						
						session_start();
						
						$_SESSION['u_id'] = $row['user_id'];
						$_SESSION['u_name'] = $row['user_name'];
						$_SESSION['u_email'] = $row['user_email'];
						$_SESSION['ac_lvl'] = $row['access_level'];
						
						header("Location: ../dashboard/examples/dashboard.php?login=success");
						exit();
					}

					if ($row['access_level'] == "2") {
						
						session_start();
						
						$_SESSION['u_id'] = $row['user_id'];
						$_SESSION['u_name'] = $row['user_name'];
						$_SESSION['u_email'] = $row['user_email'];
						$_SESSION['ac_lvl'] = $row['access_level'];

						header("Location: ../user dashboard/examples/dashboard.php?login=success");
						exit();
					}
				}
			}
			else {
				header("Location: ../login.php?error=nouser");
				exit();
			}
		} 
	}
}

else {
	header("Location: ../login.php");
	exit();
}
