<?php 

if (isset($_POST['submit'])) {

	require 'dbcon.inc.php';

	$name = $_POST['name'];  
	$email = $_POST['email'];
	$pwd = $_POST['pwd'];
	$pwdRep = $_POST['pwdRep'];

	$lvl = "2";

	if (empty($name) || empty($email) || empty($pwd)) {
		header("Location: ../signup.php?error=emptyfeilds&name=".$name."&email=".$email);
		exit();
	} 
	elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $name)) {
		header("Location: ../signup.php?error=invalidemail");
		exit();
	} 
	elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		header("Location: ../signup.php?error=token_name(token)=".$name);
		exit();
	} 
	elseif (!preg_match("/^[a-zA-Z0-9]*$/", $name)) {
		header("Location: ../signup.php?error=invalidemail&name=".$email);
		exit();
	} 
	elseif ($pwd !== $pwdRep) {
		header("Location: ../signup.php?error=passwordcheck&mail=".$name."&mail=".$email);
		exit();
	}
	else {

		$sql = "SELECT user_name FROM users WHERE user_name=?";
		$stmt = mysqli_stmt_init($conn);
		if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: ../signup.php?error=sqlerror");
			exit();
		}
		else {
		mysqli_stmt_bind_param($stmt, "s", $name);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_store_result($stmt);
		$resultCheck = mysqli_stmt_num_rows($stmt);
		if ($resultCheck > 0) {
			header("Location: ../signup.php?error=usertaken&mail=".$email);
			exit();
		}
		else {

			$sql = "INSERT INTO users(user_name, user_email, user_pwd, access_level) VAlUES (?, ?, ?, ?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: ../signup.php?error=usertaken");
			exit();
			}

			else {
				$hashedPwd = password_hash($pwd, PASSWORD_BCRYPT);

				mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hashedPwd, $lvl);
				mysqli_stmt_execute($stmt);
				header("Location: ../login.php?signup=success");
				exit();
			}
		}
	}
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

}

else {
	header("Location: ../signup.php");
	exit();
}


