<?php 

session_start();

if (isset($_POST['subscribe'])) {

	require 'dbcon.inc.php';

	$email = $_POST['newsletter_email'];  

	if (empty($email)) {
		header("Location: ../index.php?error=emptyfeilds");
		exit();
	} 
	else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		header("Location: ../index.php?error=invalid_(email)=".$email);
		exit();
	} 

	else {
		$sql = "SELECT newsletter_email FROM newsletter WHERE newsletter_email=?";
		$stmt = mysqli_stmt_init($conn);
		if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: ../index.php?error=sqlerror");
			exit();
		}
		else {
		mysqli_stmt_bind_param($stmt, "s", $email);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_store_result($stmt);
		$resultCheck = mysqli_stmt_num_rows($stmt);

		if ($resultCheck > 0) {
			header("Location: ../index.php?error=mailused&mail=".$email);
			exit();
		}
		else {
			$sql = "INSERT INTO newsletter(newsletter_email, date) VAlUES (?, NOW())";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: ../index.php?error=sqlerror");
			exit();
			}
			else {
				mysqli_stmt_bind_param($stmt, "s", $email);
				mysqli_stmt_execute($stmt);
				header("Location: ../index.php?subscription=success");
				exit();
				}
			}
		}
	}

mysqli_stmt_close($stmt);
mysqli_close($conn);

}
else {
	header("Location: ../index.php");
	exit();
}