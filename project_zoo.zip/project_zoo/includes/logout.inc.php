<?php 

session_start();

include('dbcon.inc.php');
mysqli_query($conn,"UPDATE userlog SET logout_time=NOW() WHERE user_id='".$_SESSION['u_id']."'");

session_unset();
session_destroy();

header("Location: ../index.php");
