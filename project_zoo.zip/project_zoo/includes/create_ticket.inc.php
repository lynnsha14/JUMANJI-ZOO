<?php 

if (isset($_POST['submit'])) {

	require 'dbcon.inc.php';

	$ticket_price = $_POST['t_price'];
	$ticket_name = $_POST['t_name'];
	$seat = $_POST['n_seat'];  
	$zone = $_POST['zoo_zone'];

	if (empty($ticket_price) || empty($ticket_name) || empty($seat) || empty($zone)) {
		header("Location: ../dashboard/examples/create_ticket.php?error=emptyfeilds&incomplete_form_submission");
		exit();
	}
	elseif (!preg_match("/^[a-zA-Z0-9]*$/", $ticket_name)) {
		header("Location: ../dashboard/examples/create_ticket.php?error=invalidticketname=".$ticket_name);
		exit();
	} 
	else {
		$sql = "SELECT ticket_name FROM ticket WHERE ticket_name=?";
		$stmt = mysqli_stmt_init($conn);

		if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: ../dashboard/examples/create_ticket.php?error=sqlerror");
			exit();
		}
		else {
		mysqli_stmt_bind_param($stmt, "s", $name);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_store_result($stmt);
		$resultCheck = mysqli_stmt_num_rows($stmt);
		if ($resultCheck > 0) {
			header("Location: ../dashboard/examples/create_ticket.php?error=ticketnametaken&mail=".$ticket_name);
			exit();
		}
		else {

			$sql = "INSERT INTO ticket(ticket_price, ticket_name, seat, zoo_zone) VAlUES (?, ?, ?, ?)";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt, $sql)) {
				header("Location: ../dashboard/examples/create_ticket.php?error=tickettaken");
				exit();
			}

			else {

				mysqli_stmt_bind_param($stmt, "ssss", $ticket_price, $ticket_name, $seat, $zone);
				mysqli_stmt_execute($stmt);
				header("Location: ../dashboard/examples/create_ticket.php?ticketcreated=success");
				exit();
			}
		}
	}
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

}

else {
	header("Location: ../dashboard/examples/create_ticket.php");
	exit();
}




