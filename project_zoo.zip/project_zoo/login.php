<?php 
    session_start();
    if (isset($_SESSION['u_id'])) {
       # code...
      header("Location: index.php");
   }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sign In | JUMANJI</title>

    <link rel="shortcut icon" href="images/ico/galena.ico">
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
   
    <div>
      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="includes/login.inc.php" method="POST">
              <h1>Let's get started</h1>
              <div>
                <input type="text" name="email" class="form-control" placeholder="username | email"/>
              </div>
              <div>
                <input type="password" name="pwd" class="form-control" placeholder="password"/>
              </div>
              <div>
                <button class="btn btn-default submit" name="login">Log in</button>
                <a class="reset_pass" href="#recoverPass.php">Lost your password?</a>
              </div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="signup.php" class="to_register"> Create Account </a>
                </p>
                <p class="change_link">Back to Home Page ?
                  <a href="index.php" class="to_register"> jumanji pop </a>
                </p>

                <br/>

                <div>
                  <h1 style="font-family: Bradley Hand ITC;"><i class="fa fa-cogs"></i> J U M A N J I </h1>
                  <p>&copy;<script>document.write(new Date().getFullYear())</script> All Rights Reserved. JUMANJI is a free online ZOO  provider. </p>
                </div>
              </div>
            </form>
          </section>
                   
        </div>
      </div>
  </body>
</html>
