<?php 
    session_start();
    if (isset($_SESSION['u_id'])) {
       # code...
      header("Location: index.php");
   }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sign Up | JUMANJI</title>

    <link rel="shortcut icon" href="images/ico/galena.ico">
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">

    <div>

      <div class="login_wrapper">
        <div>
          <section class="login_content">
            <form action="includes/sign.inc.php" method="POST">
              <h1>New here?</h1>
              <h1>Signing up's easy. It's few steps !</h1>
              <div>
                <input type="text" name="name" class="form-control" placeholder="username" required=""/>
              </div>
              <div>
                <input type="email" name="email" class="form-control" placeholder="email" required=""/>
              </div>
              <div>
                <input type="password" name="pwd" class="form-control" placeholder="password" required=""/>
              </div>
              <div>
                <input type="password" name="pwdRep" class="form-control" placeholder="confirm password" required=""/>
              </div>
              <div>
                <button class="btn btn-default submit" name="submit">Submit</button>
              </div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="login.php" class="to_register"> Sign In </a>
                </p>
                <p class="change_link">Back to Home Page ?
                  <a href="index.php" class="to_register"> zoo jumanji </a>
                </p>

          
                <div>
                  <p>&copy;<script>document.write(new Date().getFullYear())</script> All Rights Reserved. ZOO JUMANJI is an online zoo. Privacy and Terms</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
    <div class="" style="margin-left: 22%; margin-top: -52%;">
      <img src="images\slider\cc-abstract3.PNG">
    </div>   
    <div class="" style="margin-left: 26%; margin-top: -7%;">
      <img src="images\slider\cc-abstract2.PNG">
    </div>
  </body>
</html>
