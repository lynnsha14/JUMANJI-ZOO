<?php 
    session_start();
    if (empty($_SESSION['u_id'])) {
       # code...
      header("Location: ../../index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
 
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  
  <title>ZOO POP Dashboard</title>
  
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="./dashboard.php">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
     
          <li>
            <a href="./tickets.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Ticket List</p>
            </a>
          </li>

          <li class="active">
            <a href="./create_ticket.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Create Ticket</p>
            </a>
          </li>

        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">User Dashboard</a>
            <?php 
              if (isset($_SESSION['u_id'])) {
                echo "<p style='font-size: 20px; text-align: center; color: #c52d2f;'>welcome <span style='color: #c52d2f;'>".$_SESSION['u_name']."</span></p>";
              }
              else {
                echo '<p>you are logged-out</p>';
              }
            ?>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          
          <div class="col-md-8">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title text-center">CREATE ZOO TICKET</h5>
              </div>
              <div class="card-body">
                <form action="../../includes/create_ticket.inc.php" method="POST">
                  <div class="row">
                    <div class="col-md-10 pr-1">
                      <div class="form-group">
                        <label>Ticket Price</label>
                        <input type="text" name="t_price" class="form-control text-right" value="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-10 pr-1">
                      <div class="form-group">
                        <label>Ticket Name</label>
                        <input type="text" name="t_name" class="form-control text-right" placeholder="..." value="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-10 pr-1">
                      <div class="form-group">
                        <label>Number of Seats</label>
                        <input type="text" name="n_seat" class="form-control text-right" placeholder="..." value="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-10 pr-1">
                      <div class="form-group">
                        <label>Choose The Visitor's Zone</label>
                        <select class="form-control" name="zoo_zone" id="">
                          <option value=""></option>
                          <option value="Lion zone">Lion zone</option>
                          <option value="Giraffe zone">Giraffe zone</option>
                          <option value="Elephant zone">Elephant zone</option>
                          <option value="Crocodile zone">Crocodile zone</option>
                          <option value="Monkey zone">Monkey zone</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="update ml-auto mr-auto">
                      <button type="submit" name="submit" class="btn btn-danger btn-round">Create Ticket</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
</body>

</html>