<?php 
    session_start();
    if (empty($_SESSION['u_id'])) {
       # code...
      header("Location: ../../index.php");
   }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
 
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  
  <title>ZOO POP Dashboard</title>
  
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="sidebar-wrapper">
        <ul class="nav">
          
          <li>
            <a href="./dashboard.php">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
     
          <li class="active">
            <a href="./users_list.php">
              <i class="nc-icon nc-bell-55"></i>
              <p>User List</p>
            </a>
          </li>
          
          <li>
            <a href="./tickets.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Ticket List</p>
            </a>
          </li>

           <li>
            <a href="./create_ticket.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Create Ticket</p>
            </a>
          </li>

          <li>
            <a href="./create_user.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Create User</p>
            </a>
          </li>

        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Admin Dashboard</a>
            <?php 
              if (isset($_SESSION['u_id'])) {
                echo "<p style='font-size: 20px; text-align: center; color: #c52d2f;'>welcome <span style='color: #c52d2f;'>".$_SESSION['u_name']."</span></p>";
              }
              else {
                echo '<p>you are logged-out</p>';
              }
            ?>
          </div>
     
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <input type="text" value="" class="form-control" placeholder="Search...">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="nc-icon nc-zoom-split"></i>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title">User List Table</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        #
                      </th>
                      <th>
                        User Name
                      </th>
                      <th>
                        User Email
                      </th>
                      <th class="text-right">
                        Access Level
                      </th>
                    </thead>
                    <tbody>
                      <?php
                        $i = 1;
                        include '../../includes/dbcon.inc.php';
                        $sql = "SELECT * FROM users ORDER BY user_name ASC";
                        $stmt = mysqli_stmt_init($conn);
                          if (!mysqli_stmt_prepare($stmt, $sql)) {
                            echo("Location: users_list.php?sqlerror");
                            exit();
                          }
                          else {
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);
                            if (mysqli_num_rows($result) > 0) {
                              while ($row = mysqli_fetch_assoc($result)) {
                                  # banzance...
                                echo "<tr>";
                                echo "<td>".$i++."</td>";
                                echo "<td>".$row['user_name']."</td>";
                                echo "<td>".$row['user_email']."</td>";
                              
                              if ($row['access_level'] == 1) {
                                # code...
                                echo "<td class='text-right'>Administrator</td>";
                              }
                              if ($row['access_level'] == 2) {
                                # code...
                                echo "<td class='text-right'>Zoo Worker</td>";
                              }
                            }
                          }
                        }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
</body>

</html>